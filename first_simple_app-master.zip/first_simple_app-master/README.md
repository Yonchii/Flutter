## Example of Flutter app for webinar

### Useful links

- [Slides](https://docs.google.com/presentation/d/14F_cqlQga2FMEaGH6MQqWAFz12B9xSKWO-yEEQHbTZE/edit?usp=sharing)
- [Flutter Install](https://flutter.dev/docs/get-started/install)
- [Flutter plugin Intelliji / Android Studio](https://plugins.jetbrains.com/plugin/9212-flutter)
- [Dio](https://pub.dev/packages/dio)
- [Anitex](https://pub.dev/packages/anitex)